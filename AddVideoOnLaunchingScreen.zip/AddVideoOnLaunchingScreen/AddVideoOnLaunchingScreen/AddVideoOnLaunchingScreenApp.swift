//
//  AddVideoOnLaunchingScreenApp.swift
//  AddVideoOnLaunchingScreen
//
//  Created by Ashish Viltoriya on 19/12/23.
//

import SwiftUI

@main
struct AddVideoOnLaunchingScreenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
