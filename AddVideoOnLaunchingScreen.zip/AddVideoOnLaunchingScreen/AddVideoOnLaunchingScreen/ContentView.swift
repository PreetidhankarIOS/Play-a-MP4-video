//
//  ContentView.swift
//  AddVideoOnLaunchingScreen
//
//  Created by Ashish Viltoriya on 19/12/23.
//

import SwiftUI
import AVKit


struct ContentView: View {
    
        var body: some View {
            NavigationView {
                ZStack {
                    let player = AVPlayer(url: URL(fileURLWithPath: Bundle.main.path(forResource: "Splash", ofType: "mp4")!))
                                  VideoPlayer(player: player)
                                      .edgesIgnoringSafeArea(.all)
                                    .onAppear() {
                                        player.play()
                        }
                }
            }
        
    }
}


#Preview {
    ContentView()
}
